<?php
$host = 'localhost';
$user = 'ushahidi';
$pass = 'ScS79DsM4t5sFyN9';
$db = 'ushahidi';

$table = '';

mysql_connect($host, $user, $pass) or die(mysql_error());
mysql_select_db($db) or die(mysql_error());

$query = 'SELECT * FROM sms WHERE status = 0 ORDER BY date_rec DESC';
$result = mysql_query($query);
while($row = mysql_fetch_array( $result )) {
	echo '<a href="http://75.101.195.137/add_record.php?sms=1&sneaksms='.$row['smsid'].'">PARSE ME!</a> '.$row['number'].': '.$row['message'].'<br>
	';
}

?>