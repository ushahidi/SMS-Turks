<?php
global $title;
header('Location:search_post.php');
?>