<?php

require_once 'db.php';

if(isset($_GET['junk'])){
	set_sms_status($_GET['junk'],3);
	header('Location: add_record.php?sms=1&junksuccess=1');
}

$person_id = create_record($_POST);
if (!empty($_FILES) && !empty($_FILES['photo']['name'])) {
	handle_upload($person_id);
}

$query_string = '?success='.$_POST['firstname'].'+'.$_POST['lastname'];
if(isset($_POST['fromsms'])) $query_string .= '&sms=1';
header('Location: add_record.php'.$query_string);

//header('Location: person.php?id=' . $person_id);