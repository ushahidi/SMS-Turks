<?php
global $title;
require_once('db.php');
$title = msg('Search Results');

if (empty($_GET['page'])) $_GET['page'] = 0;
if (empty($_GET['name'])) $_GET['name'] = '';
if (empty($_GET['city'])) $_GET['city'] = '';

if (empty($_REQUEST['name']) && empty($_REQUEST['city'])) list($count, $results) = all_people();
else list($count, $results) = search_person($_REQUEST);

if (mysql_num_rows($results) == 1) {
	$row = mysql_fetch_assoc($results);
	header('Location: /person.php?id='.$row['id']);
	exit();
}

if (has_admin() && count($_POST) && !empty($_POST['person'])) {
	delete_people($_POST);
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
 "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<?php include('header.php') ?>
	<?php include_once("sidebar.php"); ?>
	<div id="content">
		<p><?php pmsg('search_intro'); ?></p>
		<?php if (!$results) { ?>
		<?php pmsg('search_nothing_found'); ?>
		<?php } else { ?>
			<?php if(has_admin()): ?>
				<form method="post">
			<?php endif; ?>
		<p>
			<?php $count = preg_replace("/\,/","",$count); ?>
				<?php pmsg('Showing Results'); ?> <?php print ($_GET['page'] * RESULTS_PER_PAGE) + 1; ?> <?php pmsg('to'); ?> <?php if(isset($_GET['page']))$p=$_GET['page']; else $p=0; print min($count, ($p * RESULTS_PER_PAGE) + RESULTS_PER_PAGE); ?> <?php pmsg('of'); ?> <?php print $count; ?>
		</p>
		
		
			<p id="pager">
				<?php if($count >= RESULTS_PER_PAGE): ?>
				
					<?php if ($_GET['page'] > 0 ): ?>
						<a href="/search_post.php?page=<?php print $_GET['page'] - 1; ?>&city=<?php print $_GET['city']; ?>&name=<?php print $_GET['name'];?>">&laquo;Previous</a>
					<?php endif; ?>
					&nbsp;
					<?php if ($_GET['page'] * RESULTS_PER_PAGE < $count - RESULTS_PER_PAGE): ?>
						<a href="/search_post.php?page=<?php print $_GET['page'] + 1; ?>&city=<?php print $_GET['city']; ?>&name=<?php print $_GET['name'];?>">Next &raquo;</a>
					<?php endif; ?>
				<?php endif; ?>
			</p>
			
			
			
		<table class="data-table">
			<thead>
				<?php if(has_admin()): ?>
					<th>&nbsp;</th>
				<?php endif; ?>
				<th><?php pmsg('Last Name'); ?></th>
				<th><?php pmsg('First Name'); ?></th>
				<th><?php pmsg('City'); ?></th>
				<th><?php pmsg('Department'); ?></th>
				<th><?php pmsg('Status'); ?></th>
			</thead>
			<tbody>
			<?php
				$row_count = -1;
				while ($row = mysql_fetch_assoc($results)) {
					$row_count++;
					$row = array_map('stripslashes', $row);
					$row_class = ($row_count % 2) ? 'odd' : 'even';
			?>
			<tr class="<?php echo $row_class; ?>">
				<?php if(has_admin()): ?>
					<td><input type="checkbox" name="person[]" value="<?php echo $row['id']; ?>" /></td>
				<?php endif; ?>
				<td><a href="/person.php?id=<?php echo $row['id']; ?>"><?php echo $row['lastname'];?></a></td>
				<td><a href="/person.php?id=<?php echo $row['id']; ?>"><?php echo $row['firstname'];?></a></td>
				<td><?php echo $row['city'];?></td>
				<td><?php echo $row['department'];?></td>
				<td><?php pmsg($row['status']);?></td>
			</tr>
			<?php } ?>
			<tr><td colspan="5">
			<p id="pager">
			<?php $count = preg_replace("/\,/","",$count); ?>
				<?php if($count >= RESULTS_PER_PAGE): ?>
				
					<?php if ($_GET['page'] > 0 ): ?>
						<a href="/search_post.php?page=<?php print $_GET['page'] - 1; ?>&city=<?php print $_GET['city']; ?>&name=<?php print $_GET['name'];?>">&laquo;Previous</a>
					<?php endif; ?>
					&nbsp;
					<?php if ($_GET['page'] * RESULTS_PER_PAGE < $count - RESULTS_PER_PAGE): ?>
						<a href="/search_post.php?page=<?php print $_GET['page'] + 1; ?>&city=<?php print $_GET['city']; ?>&name=<?php print $_GET['name'];?>">Next &raquo;</a>
					<?php endif; ?>
				<?php endif; ?>
			</p>
			</td></tr>
			</tbody>
		</table>
		<?php if(has_admin()): ?>
			<input type="submit" value="Delete Selected" onclick="return confirm('Are you sure you want to delete these people?')" />
			</form>
		<?php endif; ?>
		<?php } ?>
	</div>
</div>
</body>
</html>
