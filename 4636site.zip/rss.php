<?php
	if($_GET['key'] != 'yqNm7FHSwfdRb8nC2653') die('Key required');
?>
<?php echo "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"; ?>
<?php
	require_once('db.php');
	
	$limit = '0,50';
	if(isset($_GET['limit'])) $limit = $_GET['limit'];
	
	function last_20_updated() {
		$sth = mysql_query("SELECT firstname,lastname,city,status,id,ts,lat,lon FROM person order by ts desc limit 40") || die(mysql_error());
		return $sth;
	}
	
	function grab_reports($limit='0,50') {
		$query = "SELECT person.*, searcher.phone as phone, sms.date_rec as date_rec FROM person LEFT JOIN searcher ON person.id = searcher.person_id LEFT JOIN sms ON sms.smsid = person.smsid order by created desc limit ".mysql_escape_string($limit);
		$sth = mysql_query($query);
		return $sth;
	}
	
	$sth = grab_reports($limit);
	$rows = array();
	
	while($r = mysql_fetch_assoc($sth)) {
    $rows[] = $r;
	}
?>

<feed xmlns="http://www.w3.org/2005/Atom" xmlns:georss="http://www.georss.org/georss">
   <title>4636.ushahidi.com</title>
   <subtitle>The official database of reports to the 4636 short code in Haiti.</subtitle>
   <link href="http://4636.ushahidi.com"/>
   <author>
      <name>sms://4636</name>
   </author>
<?php
foreach ($rows as $item) { 
	echo '
	<entry>
		<id>'.$item['id'].'</id>
		<link href="http://4636.ushahidi.com/person.php?id='.$item['id'].'"/>
		<author><name>sms://'.$item['phone'].'</name></author>
		<updated>'.str_replace(' ','T',$item['ts']).'Z</updated>
		<title>'.$item['firstname'].' '.$item['lastname'].'</title>
		<sms>'.$item['sms'].'</sms>
		<smsrec>'.$item['date_rec'].'</smsrec>
		<phone>'.$item['phone'].'</phone>
		<categorization>'.str_replace('-','',$item['aid_type']).'</categorization>
		<firstname>'.$item['firstname'].'</firstname>
		<lastname>'.$item['lastname'].'</lastname>
		<status>'.$item['status'].'</status>
		<address>'.$item['address'].'</address>
		<city>'.$item['city'].'</city>
		<department>'.$item['department'].'</department>
		<summary>'.$item['sms'].'</summary>
		<notes>'.$item['notes'].'</notes>
		<georss:point>'.$item['lat'].' '.$item['lon'].'</georss:point>
	</entry>';
}
?>
</feed>
